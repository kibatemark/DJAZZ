package com.example.djazz

data class UserModel(var uid:String = "", val name:String = "", var status:String="", val photoUrl:String?)