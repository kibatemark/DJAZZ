package com.example.djazz

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v4.content.ContextCompat
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.*
import android.widget.ProgressBar
import android.widget.Toast
import com.amulyakhare.textdrawable.TextDrawable
import com.amulyakhare.textdrawable.util.ColorGenerator
import com.bumptech.glide.Glide
import com.cometchat.pro.core.CometChat
import com.cometchat.pro.core.UsersRequest
import com.cometchat.pro.exceptions.CometChatException
import com.cometchat.pro.models.User

class Contacts : AppCompatActivity() {

    lateinit var recyclerContacts: RecyclerView
    lateinit var progressLoading: ProgressBar
    lateinit var layoutManager: LinearLayoutManager
    lateinit var recyclerAdapter: ContactsRecyclerAdapter
    var contactsList = arrayListOf<UserModel>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contacts)

        setupViews()
        loadAllUsers()
    }


    override fun onPause() {
        super.onPause()
        for (user in contactsList)
        {
            CometChat.removeUserListener(getUniqueListenerId(user.uid))
        }
    }

    fun setupViews()
    {
        // progress bar
        progressLoading = findViewById(R.id.progressLoading)

        // RecyclerView
        recyclerContacts = findViewById(R.id.recyclerContacts)
        layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        recyclerContacts.layoutManager = layoutManager
        recyclerAdapter = ContactsRecyclerAdapter(this)
        recyclerContacts.adapter = recyclerAdapter
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_contacts, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when(item?.itemId)
        {
            R.id.menuProfile -> {
                val intent = Intent(this, profile::class.java)
                startActivity(intent)
            }
        }
        return true
    }

    fun loadAllUsers()
    {
        // Show Progress Bar
        progressLoading.visibility = View.VISIBLE
        recyclerContacts.visibility = View.GONE

        // Load All Users from Comet Chat
        val usersRequest = UsersRequest.UsersRequestBuilder().setLimit(50).build()
        usersRequest.fetchNext(object : CometChat.CallbackListener<List<User>>() {
            override fun onSuccess(usersList: List<User>?) {
                if (usersList != null)
                {
                    val loggedInUser = CometChat.getLoggedInUser()
                    for (user in usersList)
                    {
                        // Don't add yourself (logged in user) in the list
                        if (loggedInUser.uid != user.uid)
                        {
                            contactsList.add(user.convertToUserModel())

                            // Add Online/Offline Listener
                            CometChat.addUserListener(getUniqueListenerId(user.uid), object : CometChat.UserListener() {
                                override fun onUserOffline(offlineUser: User?) {
                                    super.onUserOffline(offlineUser)
                                    user.let {
                                        searchUserWithId(contactsList, it.uid)?.let {
                                            contactsList[it].status = "offline"
                                            recyclerAdapter.notifyItemChanged(it)

                                        }
                                    }

                                }

                                override fun onUserOnline(user: User?) {
                                    super.onUserOnline(user)
                                    user?.let {
                                        searchUserWithId(contactsList, it.uid)?.let {
                                            contactsList[it].status = "online"
                                            recyclerAdapter.notifyItemChanged(it)

                                        }
                                    }
                                }
                            })
                        }
                    }

                    // Update the Recycler Adapter
                    recyclerAdapter.notifyDataSetChanged()
                }
                else
                {
                    Toast.makeText(this@Contacts, "Couldn't load the users!", Toast.LENGTH_SHORT).show()
                }

                // Hide Progress
                progressLoading.visibility = View.GONE
                recyclerContacts.visibility = View.VISIBLE
            }

            override fun onError(exception: CometChatException?) {

                // Hide Progress
                progressLoading.visibility = View.GONE
                recyclerContacts.visibility = View.VISIBLE

                Toast.makeText(this@Contacts, exception?.localizedMessage ?: "Unknown error occurred!", Toast.LENGTH_SHORT).show()
            }
        })
    }

   /* fun loadDummyData()
    {
        contactsList.add(UserModel("John Doe", "Online", "https://cdn.pixabay.com/photo/2013/07/13/10/07/man-156584_960_720.png", "https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn.pixabay.com%2Fphoto%2F2018%2F05%2F17%2F11%2F14%2Fletter-3408291__340.png&imgrefurl=https%3A%2F%2Fpixabay.com%2Fimages%2Fsearch%2Fcapital%2520letter%2F&docid=bJtx_2_ui-P4aM&tbnid=CT9G-jIOvsHCCM%3A&vet=10ahUKEwjT1cm80s3kAhUnz6YKHfXlDUwQMwh1KAAwAA..i&w=340&h=340&client=opera&bih=601&biw=1263&q=letter%20images&ved=0ahUKEwjT1cm80s3kAhUnz6YKHfXlDUwQMwh1KAAwAA&iact=mrc&uact=8"))
        contactsList.add(UserModel("Alexa Johnson", "Offline", "https://previews.123rf.com/images/juliasart/juliasart1704/juliasart170400022/75406270-vector-girl-icon-woman-avatar-face-icon-cartoon-style-.jpg", "https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn.pixabay.com%2Fphoto%2F2018%2F05%2F17%2F11%2F14%2Fletter-3408291__340.png&imgrefurl=https%3A%2F%2Fpixabay.com%2Fimages%2Fsearch%2Fcapital%2520letter%2F&docid=bJtx_2_ui-P4aM&tbnid=CT9G-jIOvsHCCM%3A&vet=10ahUKEwjT1cm80s3kAhUnz6YKHfXlDUwQMwh1KAAwAA..i&w=340&h=340&client=opera&bih=601&biw=1263&q=letter%20images&ved=0ahUKEwjT1cm80s3kAhUnz6YKHfXlDUwQMwh1KAAwAA&iact=mrc&uact=8"))
        contactsList.add(UserModel("Robert Smith", "Online", "https://i.pinimg.com/originals/a7/0e/16/a70e1675c7bc001f1578aa76bb0a7819.png", "https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn.pixabay.com%2Fphoto%2F2018%2F05%2F17%2F11%2F14%2Fletter-3408291__340.png&imgrefurl=https%3A%2F%2Fpixabay.com%2Fimages%2Fsearch%2Fcapital%2520letter%2F&docid=bJtx_2_ui-P4aM&tbnid=CT9G-jIOvsHCCM%3A&vet=10ahUKEwjT1cm80s3kAhUnz6YKHfXlDUwQMwh1KAAwAA..i&w=340&h=340&client=opera&bih=601&biw=1263&q=letter%20images&ved=0ahUKEwjT1cm80s3kAhUnz6YKHfXlDUwQMwh1KAAwAA&iact=mrc&uact=8"))
        contactsList.add(UserModel("Steve Boam", "Online", "https://cdn1.iconfinder.com/data/icons/people-faces-2/512/11-512.png", "https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn.pixabay.com%2Fphoto%2F2018%2F05%2F17%2F11%2F14%2Fletter-3408291__340.png&imgrefurl=https%3A%2F%2Fpixabay.com%2Fimages%2Fsearch%2Fcapital%2520letter%2F&docid=bJtx_2_ui-P4aM&tbnid=CT9G-jIOvsHCCM%3A&vet=10ahUKEwjT1cm80s3kAhUnz6YKHfXlDUwQMwh1KAAwAA..i&w=340&h=340&client=opera&bih=601&biw=1263&q=letter%20images&ved=0ahUKEwjT1cm80s3kAhUnz6YKHfXlDUwQMwh1KAAwAA&iact=mrc&uact=8"))
        recyclerAdapter.notifyDataSetChanged()
    }
*/
    inner class ContactsRecyclerAdapter(val context: Context) : RecyclerView.Adapter<ContactsRecyclerAdapter.ContactViewHolder>()
    {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
            return ContactViewHolder(LayoutInflater.from(this@Contacts).inflate(R.layout.contact_item_layout, parent, false))
        }

        override fun getItemCount(): Int = contactsList.size

        override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
            val user = contactsList[position]
            holder.bindItem(user) {
                val intent = Intent(context, chat::class.java)
                intent.putExtra("uid", user.uid)
                intent.putExtra("name", user.name)
                intent.putExtra("status", user.status)
                intent.putExtra("photo", user.photoUrl)
                context.startActivity(intent)
            }
        }

        inner class ContactViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
        {
            var txtUsername: AppCompatTextView
            var txtStatus: AppCompatTextView
            var imgContactPhoto: AppCompatImageView
            var userItemClickCallback: (() -> Unit)? = null

            init {
                txtUsername = itemView.findViewById(R.id.txtUsername)
                txtStatus = itemView.findViewById(R.id.txtStatus)
                imgContactPhoto = itemView.findViewById(R.id.imgContactPhoto)
                val cardRootLayout = itemView.findViewById<ConstraintLayout>(R.id.cardRootLayout)
                cardRootLayout.setOnClickListener {
                    userItemClickCallback?.invoke()
                }
            }

            fun bindItem(userModel: UserModel, callback: () -> Unit)
            {
                userItemClickCallback = callback
                txtUsername.text = userModel.name

                if (userModel.photoUrl != null && !userModel.photoUrl.isEmpty())
                {
                    // Load Avatar Image if any
                    Glide.with(context)
                        .asBitmap()
                        .load(userModel.photoUrl)
                        .into(imgContactPhoto)
                }
                else
                {
                    // Generate Letter Avatar
                    setAvatarImage(userModel.name[0].toString())
                }

                txtStatus.text = userModel.status
                if (userModel.status.equals("online"))
                   // txtStatus.setTextColor(context.resources.getColor(R.color.colorOnline))
                txtStatus.setTextColor(ContextCompat.getColor(applicationContext,
                    R.color.colorOnline))
                else
                   // txtStatus.setTextColor(context.resources.getColor(R.color.colorOffline))
                txtStatus.setTextColor(ContextCompat.getColor(applicationContext,
                    R.color.colorOffline))
            }

            fun setAvatarImage(letter: String)
            {
                val generator = ColorGenerator.MATERIAL
                val color = generator.randomColor

                val drawable = TextDrawable.builder().buildRect(letter, color)
                imgContactPhoto.setImageDrawable(drawable)
            }
        }
    }

}
