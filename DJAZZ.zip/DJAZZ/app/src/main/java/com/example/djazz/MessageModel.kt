package com.example.djazz

data class MessageModel (
    val message:String = "",
    val isMine:Boolean =true)